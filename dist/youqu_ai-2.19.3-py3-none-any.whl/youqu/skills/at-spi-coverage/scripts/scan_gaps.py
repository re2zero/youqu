#!/usr/bin/env python3
"""AT-API info gap scanner — instance-level C++ source analysis.

Scans C++/Qt/DTK source code for UI widget member variables that lack
setObjectName() and setAccessibleName() calls. Operates at the *instance*
level: knows which member variable is missing a name, not just which class.

Dependencies: python3-clang-18, libclang-18-dev, PyYAML, Python stdlib.

Usage:
    scan_gaps.py --src <source_dir> --build <build_dir> --output <output_dir>
    scan_gaps.py --src <source_dir> --compile-commands <cc.json> --output <output_dir>

Output (in <output_dir>):
    pre_scan_ok.yaml   — widget instances that already have names
    pre_scan_gaps.yaml — widget instances missing names (with location info)
    pre_report.json    — summary statistics
"""

from __future__ import annotations

import argparse
import json
import logging
import multiprocessing
import os
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger("scan_gaps")

# ---------------------------------------------------------------------------
# libclang setup — MUST call Config.set_library_path() BEFORE any import
# ---------------------------------------------------------------------------

_LIBCLANG_CANDIDATES = [
    "/usr/lib/x86_64-linux-gnu",
    "/usr/lib64",
    "/usr/lib",
    "/usr/lib/llvm-18/lib",
    "/usr/lib/llvm-17/lib",
    "/usr/lib/llvm-19/lib",
]

_libclang_libpath: str | None = None
for _base in _LIBCLANG_CANDIDATES:
    _p = Path(_base)
    if not _p.is_dir():
        continue
    try:
        for _f in _p.iterdir():
            if "libclang" in _f.name and _f.suffix in (".so", ".so.1"):
                _libclang_libpath = _base
                break
    except OSError:
        continue
    if _libclang_libpath:
        break

if _libclang_libpath:
    _key = "LD_LIBRARY_PATH"
    _old = os.environ.get(_key, "")
    if _libclang_libpath not in _old:
        os.environ[_key] = f"{_libclang_libpath}:{_old}" if _old else _libclang_libpath
    from clang.cindex import Config
    Config.set_library_path(_libclang_libpath)
    _LIBCLANG_READY = True
else:
    _LIBCLANG_READY = False

try:
    from clang.cindex import CursorKind, Index
    _LIBCLANG_IMPORT_OK = True
except ImportError:
    CursorKind = None  # type: ignore
    _LIBCLANG_IMPORT_OK = False


# ---------------------------------------------------------------------------
# Type database — loaded from generated JSON
# ---------------------------------------------------------------------------

_TYPE_DB_PATH = Path(__file__).resolve().parent / "type_db.json"


class TypeDatabase:
    """Loads and queries the type classification database.

    The database (type_db.json) contains inheritance-based classification for
    all DTK and Qt widget types. Falls back to hardcoded sets when the DB file
    is unavailable.
    """

    def __init__(self, db_path: str | Path | None = None) -> None:
        self._db: dict | None = None
        self._custom_types: dict[str, str] = {}  # name -> category
        self._custom_bases: dict[str, str] = {}  # name -> direct base class
        self._load(db_path or _TYPE_DB_PATH)

    def _load(self, path: str | Path) -> None:
        p = Path(path)
        if p.is_file():
            try:
                import json
                with open(p) as f:
                    self._db = json.load(f)
                logger.info("Loaded type DB: %s (%d classes)", p, len(self._db.get("classes", {})))
            except Exception as e:
                logger.warning("Failed to load type DB %s: %s", p, e)
                self._db = None
        else:
            logger.warning("Type DB not found: %s — using fallback sets", p)
            self._db = None

    def _classify(self, type_name: str) -> str:
        """Classify a type name using the DB and inheritance chain.

        Follows the inheritance chain (bases) to find the best category.
        """
        base = type_name.replace(" *", "").replace("&", "").split("<")[0].strip()

        # Check custom types first (project-specific)
        if base in self._custom_types:
            return self._custom_types[base]

        if self._db is None:
            return "unknown"

        classes = self._db.get("classes", {})
        qt_roots = self._db.get("qt_roots", {})

        # Follow inheritance chain until we find a non-unknown category
        seen = set()
        current = base
        while current and current not in seen:
            seen.add(current)

            # Direct lookup
            info = classes.get(current)
            if info:
                cat = info.get("category", "unknown")
                if cat != "unknown":
                    return cat
                # Follow bases
                bases = info.get("bases", [])
                if bases:
                    current = bases[0]  # Primary base class
                    # Strip namespace
                    if "::" in current:
                        current = current.split("::")[-1]
                    continue

            # Check Qt roots
            if current in qt_roots.get("interactive", []):
                return "interactive"
            if current in qt_roots.get("decorative", []):
                return "decorative"
            if current in qt_roots.get("layout", []):
                return "layout"

            # Suffix matching for template types
            # current is set to None above when no bases found
            if current is None:
                break
            matched = False
            for cls_name, info in classes.items():
                if len(cls_name) < 4:
                    continue
                if current.endswith(cls_name):
                    cat = info.get("category", "unknown")
                    if cat != "unknown":
                        return cat
                    bases = info.get("bases", [])
                    if bases:
                        current = bases[0].split("::")[-1] if "::" in bases[0] else bases[0]
                        matched = True
                        break
                    else:
                        current = None
                        matched = True
                        break
            if not matched:
                current = None
        # This handles QPushButton -> QAbstractButton chain breakage.
        for ancestor in seen:
            if ancestor in qt_roots.get("interactive", []):
                return "interactive"
            if ancestor in qt_roots.get("decorative", []):
                return "decorative"
            if ancestor in qt_roots.get("layout", []):
                return "layout"

        # Final fallback: well-known Qt widget types whose bases are missing in DB
        # (e.g. QPushButton has bases=[], category=unknown but inherits from QAbstractButton)
        # Check each ancestor in the chain, not just the original base.
        _KNOWN_QT_INTERACTIVE = frozenset({
            "QPushButton", "QToolButton", "QCheckBox", "QRadioButton",
            "QLineEdit", "QTextEdit", "QPlainTextEdit", "QComboBox",
            "QSlider", "QSpinBox", "QDoubleSpinBox", "QScrollBar",
            "QListWidget", "QTreeWidget", "QTableWidget",
            "QListView", "QTreeView", "QTableView",
            "QTabBar", "QKeySequenceEdit",
            "QMenu", "QMenuBar",
            "QAction", "QActionGroup", "QShortcut",
            "QButtonGroup",
            "QDialogButtonBox", "QCalendarWidget", "QFontComboBox",
            "QAbstractItemView", "QAbstractScrollArea",
        })
        _KNOWN_QT_DECORATIVE = frozenset({
            "QWidget", "QMainWindow", "QDialog", "QWindow", "QFrame",
            "QLabel", "QProgressBar", "QGraphicsView",
            "QGroupBox", "QScrollArea", "QSplitter",
            "QStackedWidget", "QStatusBar", "QTabWidget", "QToolBar",
        })
        for ancestor in seen:
            if ancestor in _KNOWN_QT_INTERACTIVE:
                return "interactive"
            if ancestor in _KNOWN_QT_DECORATIVE:
                return "decorative"
        return "unknown"
    def is_ui_type(self, type_name: str) -> bool:
        """Check if a type is any known UI type."""
        return self._classify(type_name) != "unknown"

    def is_interactive(self, type_name: str) -> bool:
        """Check if a type is an interactive widget (needs AT-SPI names)."""
        return self._classify(type_name) == "interactive"

    def is_layout(self, type_name: str) -> bool:
        return self._classify(type_name) == "layout"

    def is_decorative(self, type_name: str) -> bool:
        return self._classify(type_name) == "decorative"

    def register_custom_type(self, name: str, category: str) -> None:
        """Register a project-specific type that isn't in the DB."""
        self._custom_types[name] = category

    def resolve_custom_types(self, source_dir: str | Path,
                             project_includes: list[str] | None = None) -> None:
        """Scan project headers for custom widget types and classify them.

        For types that inherit from known Qt/DTK interactive classes,
        register them as interactive. Uses fast text-based grep instead of
        clang parsing (which is too slow: 2-3s per header).
        """
        if not _LIBCLANG_READY:
            return

        root = Path(source_dir)
        if not root.is_dir():
            return

        # Fast text-based grep: extract class name and base class from headers
        all_headers = sorted(root.rglob("*.h"))
        found = 0
        for h in all_headers:
            try:
                content = h.read_text(errors="replace")
                if "class " not in content or ": public " not in content:
                    continue
                for line in content.splitlines():
                    line = line.strip()
                    if line.startswith("class ") and ": public " in line:
                        cls_name = line.split(":")[0].replace("class", "").strip()
                        if cls_name and not cls_name.startswith("Q") and not cls_name.startswith("D"):
                            # Extract base class name
                            base_raw = line.split(": public ")[-1].split("{")[0].strip()
                            base_raw = base_raw.split("::")[-1] if "::" in base_raw else base_raw
                            base_raw = base_raw.split("<")[0].strip()
                            cat = self._classify(base_raw)
                            if cat != "unknown" and cls_name not in self._custom_types:
                                self._custom_types[cls_name] = cat
                                self._custom_bases[cls_name] = base_raw
                                found += 1
                                # No break — one file may have multiple custom types
            except Exception:
                continue
        logger.info("resolve_custom_types: found %d custom types (parsed %d headers)", found, len(all_headers))

_TYPE_DB = TypeDatabase()

_DTK_WIDGET_CLASSES: frozenset[str] = frozenset({
    "DWidget", "DMainWindow", "DWindow", "DFrame",
    "DAbstractDialog", "DDialog", "DDialogCloseButton",
    "DAboutDialog", "DInputDialog", "DFeatureDisplayDialog",
    "DPushButton", "DToolButton", "DIconButton", "DSwitchButton",
    "DSuggestButton", "DCommandLinkButton", "DButtonBox", "DFloatingButton",
    "DLineEdit", "DTextEdit", "DComboBox", "DCheckBox", "DRadioButton",
    "DSlider", "DSpinBox", "DPasswordEdit", "DSearchEdit", "DFileChooserEdit",
    "DLabel", "DTitlebar", "DProgressBar", "DIndeterminateProgressBar",
    "DWaterProgress", "DAlertControl",
    "DTabBar", "DListView", "DTreeView", "DStackWidget", "DDrawer",
    "DFloatingWidget", "DToolBox",
    "DFlowLayout", "DHeaderLine", "DShadowLine",
    "DMenuBar", "DStatusBar", "DMenu", "DAction", "DMenuItem",
    "DSettings", "DSettingsWidget",
    "DArrowRectangle", "DToolTip", "DSegmentedControl", "DClipEffectWidget",
    "DAbstractButton",
    "DFlyoutWidget", "DMessageBox",
    "DViewItemAction",
    "DMessageManager", "DHBoxWidget", "DBoxWidget",
    "DSettingsDialog", "DVerticalLine", "DWindowCloseButton",
    "DKeySequenceEdit", "DFloatingMessage",
})

_QT_UI_CLASSES: frozenset[str] = frozenset({
    "QWidget", "QMainWindow", "QDialog", "QWindow",
    "QMenu", "QMenuBar", "QStatusBar", "QToolBar",
    "QPushButton", "QToolButton", "QLabel", "QLineEdit",
    "QTextEdit", "QComboBox", "QCheckBox", "QRadioButton",
    "QSlider", "QSpinBox", "QDoubleSpinBox",
    "QTabWidget", "QTabBar", "QListView", "QTreeView", "QTableView",
    "QScrollArea", "QGroupBox", "QFrame", "QStackedWidget",
    "QSplitter", "QProgressBar", "QListWidget", "QTreeWidget", "QTableWidget",
    "QGraphicsView", "QScrollBar",
    "QAction", "QActionGroup", "QShortcut",
    "QButtonGroup", "QStackedLayout",
    "QHBoxLayout", "QVBoxLayout", "QGridLayout", "QFormLayout",
})

_ALL_UI_CLASSES = _DTK_WIDGET_CLASSES | _QT_UI_CLASSES

_LAYOUT_CLASSES: frozenset[str] = frozenset({
    "QHBoxLayout", "QVBoxLayout", "QGridLayout", "QFormLayout",
    "QStackedLayout", "QBoxLayout",
})

_INTERACTIVE_CLASSES: frozenset[str] = frozenset({
    "DPushButton", "DToolButton", "DIconButton", "DSwitchButton",
    "DSuggestButton", "DCommandLinkButton", "DFloatingButton",
    "DLineEdit", "DTextEdit", "DComboBox", "DCheckBox", "DRadioButton",
    "DSlider", "DSpinBox", "DPasswordEdit", "DSearchEdit", "DFileChooserEdit",
    "QPushButton", "QToolButton", "QLineEdit", "QTextEdit", "QComboBox",
    "QCheckBox", "QRadioButton", "QSlider", "QSpinBox", "QDoubleSpinBox",
    "QListWidget", "QTreeWidget", "QTableWidget", "QListView", "QTreeView",
    "QTableView", "QTabBar", "QScrollBar",
    "QMenu", "QMenuBar", "QAction", "QActionGroup", "QShortcut",
    "QButtonGroup", "QDialogButtonBox", "QCalendarWidget", "QKeySequenceEdit",
    "DAction", "DMenu", "DMenuItem", "DMenuBar",
    "DTabBar", "DListView", "DTreeView",
    "DKeySequenceEdit",
    "DAbstractButton",
})

_NON_WIDGET_INTERACTIVE: frozenset[str] = frozenset({
    # Pure QObject types — only setObjectName() is available, no setAccessibleName()
    "QAction", "QActionGroup", "QShortcut",
    "QButtonGroup",
    "DAction",
})

_DECORATIVE_CLASSES: frozenset[str] = frozenset({
    "DLabel", "DTitlebar", "DProgressBar", "DIndeterminateProgressBar",
    "DWaterProgress", "DAlertControl",
    "DHeaderLine", "DShadowLine", "DVerticalLine",
    "DArrowRectangle", "DToolTip", "DClipEffectWidget",
    "DFlyoutWidget", "DMessageBox",
    "DFloatingMessage", "DFloatingWidget", "DDrawer",
    "DSegmentedControl",
    "DGroupBox", "DScrollArea", "DSplitter",
    "DStackedWidget", "DStatusBar", "DTabWidget", "DToolBar",
    "QLabel", "QProgressBar", "QFrame", "QGraphicsView",
    "QMainWindow", "QWidget", "QDialog", "QWindow",
    "QGroupBox", "QScrollArea", "QSplitter",
    "QStackedWidget", "QStatusBar", "QTabWidget", "QToolBar",
})


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------


@dataclass
class WidgetInstance:
    """A widget instance found in source code."""
    variable: str = ""
    type_name: str = ""
    source_file: str = ""
    class_name: str = ""
    line: int = 0
    instantiation: str = ""
    has_object_name: bool = False
    has_accessible_name: bool = False
    existing_object_name: str = ""
    existing_accessible_name: str = ""
    display_text: str = ""
    role: str = ""
    context: str = ""
    is_action: bool = False
    action_owner: str = ""


@dataclass
class ScanResult:
    source_dir: str
    total_files: int = 0
    parsed_files: int = 0
    failed_files: int = 0
    widgets: list[WidgetInstance] = field(default_factory=list)
    ok_widgets: list[WidgetInstance] = field(default_factory=list)
    gap_widgets: list[WidgetInstance] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Role mapping
# ---------------------------------------------------------------------------

_TYPE_TO_ROLE: dict[str, str] = {
    "push button": "push button",
    "tool button": "push button",
    "check box": "check box",
    "radio button": "radio button",
    "combo box": "combo box",
    "spin box": "spin box",
    "slider": "slider",
    "scroll bar": "scroll bar",
    "progress bar": "progress bar",
    "line edit": "text",
    "text edit": "text",
    "label": "label",
    "menu": "menu",
    "menu item": "menu item",
    "menu bar": "menu bar",
    "tool bar": "tool bar",
    "status bar": "status bar",
    "tab": "page tab",
    "tab widget": "page tab list",
    "list view": "list",
    "tree view": "tree",
    "table view": "table",
    "scroll area": "scroll pane",
    "splitter": "split pane",
    "group box": "grouping",
    "frame": "frame",
    "stacked widget": "layered pane",
    "action": "push button",
    "shortcut": "accelerator label",
    "key sequence edit": "text",
}


def _map_role(type_name: str) -> str:
    """Map a C++ type to an AT-SPI role."""
    base = type_name.replace(" *", "").replace("&", "").split("<")[0].strip()
    if base.startswith("D") and len(base) > 1 and base[1].isupper():
        base = base[1:]
    base_nospace = base.lower().replace(" ", "")
    for key, role in _TYPE_TO_ROLE.items():
        key_nospace = key.lower().replace(" ", "")
        if key_nospace in base_nospace:
            return role
    return ""


# ---------------------------------------------------------------------------
# Type classification helpers
# ---------------------------------------------------------------------------


def _is_ui_type(type_name: str) -> bool:
    base = type_name.replace(" *", "").replace("&", "").split("<")[0].strip()
    # Try type DB first
    if _TYPE_DB.is_ui_type(base):
        return True
    # Fallback to hardcoded sets
    if base in _ALL_UI_CLASSES:
        return True
    for cls in _ALL_UI_CLASSES:
        if base.endswith(cls):
            return True
    return False


def _is_interactive_type(type_name: str) -> bool:
    base = type_name.replace(" *", "").replace("&", "").split("<")[0].strip()
    # Try type DB first
    if _TYPE_DB.is_interactive(base):
        return True
    # Fallback to hardcoded sets
    if base in _INTERACTIVE_CLASSES:
        return True
    for cls in _INTERACTIVE_CLASSES:
        if base.endswith(cls):
            return True
    return False


def _is_non_widget_interactive(type_name: str) -> bool:
    """Check if a type is interactive but NOT a QWidget (no setAccessibleName())."""
    base = type_name.replace(" *", "").replace("&", "").split("<")[0].strip()
    if base in _NON_WIDGET_INTERACTIVE:
        return True
    for cls in _NON_WIDGET_INTERACTIVE:
        if base.endswith(cls):
            return True
    # Follow the inheritance chain (custom types + type DB) to a non-widget
    # root, e.g. ColorWidgetAction -> QWidgetAction -> QAction.
    current = _TYPE_DB._custom_bases.get(base, base)
    classes = _TYPE_DB._db.get("classes", {}) if _TYPE_DB._db else {}
    seen: set[str] = set()
    while current and current not in seen:
        seen.add(current)
        if current in _NON_WIDGET_INTERACTIVE:
            return True
        info = classes.get(current)
        if not info:
            break
        bases = info.get("bases", [])
        if not bases:
            break
        current = bases[0]
        if "::" in current:
            current = current.split("::")[-1]
    return False


def _is_layout_type(type_name: str) -> bool:
    base = type_name.replace(" *", "").replace("&", "").split("<")[0].strip()
    if _TYPE_DB.is_layout(base):
        return True
    return base in _LAYOUT_CLASSES


def _is_decorative_type(type_name: str) -> bool:
    base = type_name.replace(" *", "").replace("&", "").split("<")[0].strip()
    if _TYPE_DB.is_decorative(base):
        return True
    return base in _DECORATIVE_CLASSES


def _is_widget_pointer_type(type_name: str) -> bool:
    """Check if a type name looks like a pointer to a potential widget class.

    Broad admission filter for Pass 1: admits anything that *might* be a widget
    pointer. Narrow classification happens in Pass 3 via _is_interactive_type().
    """
    return type_name.endswith("*") and not type_name.startswith("Q") and not type_name.startswith("D")


# ---------------------------------------------------------------------------
# Local class resolution (same-name shadowing protection)
# ---------------------------------------------------------------------------

# Matches a class definition line that names its base, e.g.:
#   class IconLabel : public QWidget {
#   class RenameEdit : public DTK_WIDGET_NAMESPACE::DTextEdit
# (Same text-based technique as resolve_custom_types — robust across
# libclang versions that hide CXX_BASE_SPECIFIER children.)
_LOCAL_CLASS_RE = re.compile(
    r"^\s*class\s+([A-Za-z_]\w*)\s*:\s*public\s+"
    r"([A-Za-z_]\w*(?:::[A-Za-z_]\w+)*)\s*(?:[<{;,+]|$)"
)


def _collect_local_class_bases(file_path: str, header_path: str | None) -> dict[str, str]:
    """Collect classes defined in the scanned .cpp (and its matching header)
    together with their direct base class, as a text scan.

    Used to correct classification when a local class shadows a same-named
    header interactive type (e.g. a decorative '*IconLabel* : public QWidget'
    defined inside a .cpp shadowing iconutils.h's interactive IconLabel).
    """
    bases: dict[str, str] = {}
    files = [file_path]
    if header_path:
        files.append(header_path)
    for p in files:
        try:
            content = Path(p).read_text(errors="replace")
        except Exception:
            continue
        for raw in content.splitlines():
            m = _LOCAL_CLASS_RE.match(raw.strip())
            if not m:
                continue
            name, base = m.group(1), m.group(2)
            if not name.startswith(("Q", "D", "K", "G")):
                bases.setdefault(name, base.split("::")[-1].split("<")[0].strip())
    return bases


def _resolve_local_base(type_name: str, local_bases: dict[str, str]) -> str:
    """Resolve a pointer type through locally-defined class bases in a TU.

    A translation unit may define a local class (e.g. 'class IconLabel :
    public QWidget' inside a .cpp) that shadows a same-named interactive class
    declared in a header and registered by resolve_custom_types().
    Classification must use the real base (wins over the global table) so
    decorative local helpers are not misreported as interactive gaps.
    """
    base = type_name.replace(" *", "").replace("&", "").split("<")[0].strip()
    seen = set()
    while base in local_bases and base not in seen:
        seen.add(base)
        base = local_bases[base]
    return base


# ---------------------------------------------------------------------------
# Libclang helpers
# ---------------------------------------------------------------------------


def _extract_string_literal(cursor) -> str | None:
    """Extract a string literal from a cursor subtree."""
    for child in cursor.get_children():
        try:
            if child.kind == CursorKind.STRING_LITERAL:
                text = child.spelling.strip('"')
                if text:
                    return text
            result = _extract_string_literal(child)
            if result:
                return result
        except Exception:
            continue
    return None


# ---------------------------------------------------------------------------
# Compile commands loading
# ---------------------------------------------------------------------------


def _load_compile_commands(cc_path: str) -> dict[str, list[str]] | None:
    """Load compile_commands.json and return per-file flags."""
    try:
        with open(cc_path) as f:
            entries = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as e:
        logger.warning("Failed to load %s: %s", cc_path, e)
        return None

    result: dict[str, list[str]] = {}
    for entry in entries:
        file_path = entry.get("file", "")
        if not file_path.endswith((".cpp", ".cxx", ".cc")):
            continue
        cmd_str = entry.get("command", "")
        if not cmd_str:
            continue
        parts = cmd_str.split()
        if parts and (parts[0].endswith("c++") or "clang" in parts[0] or parts[0] == "cc"):
            parts = parts[1:]
        flags: list[str] = []
        skip_next = False
        for p in parts:
            if skip_next:
                skip_next = False
                continue
            if p == "-c":
                continue
            if p in ("-o", "-MQ", "-MF", "-MT"):
                skip_next = True
                continue
            if p.startswith("-o") or p.endswith(".o") or p.endswith(".obj"):
                continue
            if p == file_path or p in ("-MD", "-MMD", "-MP"):
                continue
            flags.append(p)
        result[file_path] = flags
    return result


# ---------------------------------------------------------------------------
# C++ stdlib and Qt include flags (fallback when no compile_commands.json)
# ---------------------------------------------------------------------------


def _get_cxx_stdlib_flags() -> list[str]:
    flags: list[str] = []
    for dirpath in ["/usr/include/c++/13", "/usr/include/c++/12", "/usr/include/c++/11",
                     "/usr/include/x86_64-linux-gnu/c++/13",
                     "/usr/include/x86_64-linux-gnu/c++/12",
                     "/usr/include/x86_64-linux-gnu/c++/11"]:
        if Path(dirpath).is_dir():
            flags.extend(["-isystem", dirpath])
    return flags

def _probe_qt_base() -> list[str]:
    """Probe for Qt base include directories."""
    bases = []
    for base in ["/usr/include/x86_64-linux-gnu/qt6", "/usr/include/qt6",
                  "/usr/include/x86_64-linux-gnu/qt5", "/usr/include/qt5"]:
        if Path(base).is_dir():
            bases.append(base)
    return bases


def _probe_dtk_base() -> list[str]:
    """Probe for DTK base include directories."""
    bases = []
    for base in ["/usr/include/x86_64-linux-gnu/dtk6", "/usr/include/dtk6",
                  "/usr/include/x86_64-linux-gnu/dtk5", "/usr/include/dtk5",
                  "/usr/include/DtkWidget", "/usr/include/DtkGui"]:
        if Path(base).is_dir():
            bases.append(base)
    return bases


def _get_qt_dtk_include_flags() -> list[str]:
    """Auto-detect Qt and DTK include paths.

    Includes all Qt subdirectories for full symbol resolution in the main scan.
    Only includes specific DTK subdirectories (DWidget, DCore, DGui).
    """
    flags: list[str] = []
    for base in _probe_qt_base():
        flags.extend(["-isystem", base])
        for sub in Path(base).iterdir():
            if sub.is_dir():
                flags.extend(["-isystem", str(sub)])
    for base in _probe_dtk_base():
        for sub in ["DWidget", "DCore", "DGui"]:
            sp = Path(base) / sub
            if sp.is_dir():
                flags.extend(["-isystem", str(sp)])
    return flags


# ---------------------------------------------------------------------------
# Source-scoped cursor iteration (performance optimization)
# ---------------------------------------------------------------------------


def _iter_source_cursors(root_cursor, source_path: str, header_path: str | None = None):
    """Yield cursors only from the source file or its matching header.

    Skips entire subtrees rooted in system headers — this is the key
    performance optimization over walk_preorder() which visits every node
    in the entire translation unit (including Qt, STL, etc.).
    """
    allowed = {source_path}
    if header_path:
        allowed.add(header_path)

    def _walk(c):
        try:
            loc = c.location
            if loc and loc.file and loc.file.name not in allowed:
                return
            yield c
            for child in c.get_children():
                yield from _walk(child)
        except Exception:
            pass

    for top in root_cursor.get_children():
        yield from _walk(top)


def _get_header_path(file_path: str) -> str | None:
    """Find the matching header file for a source file."""
    p = Path(file_path)
    for ext in ('.h', '.hpp', '.hh'):
        h = p.with_suffix(ext)
        if h.is_file():
            return str(h)
    return None


# ---------------------------------------------------------------------------
# Unexposed expression handler
# ---------------------------------------------------------------------------


def _detect_call_in_unexposed(
    cursor,
    widgets: dict[str, WidgetInstance],
    name_calls: dict[str, set[tuple[str, str]]],
    named_calls: dict[str, set[str]],
) -> None:
    """Detect setObjectName/setAccessibleName calls inside UNEXPOSED_EXPR nodes.

    Pointer-member calls (m_ptr->setObjectName(...)) are parsed as UNEXPOSED_EXPR
    instead of CALL_EXPR by libclang when the pointer type is incomplete.
    """
    try:
        children = list(cursor.get_children())
        if not children:
            return

        callee_name = ""
        target_var = ""
        name_value = ""

        for child in children:
            if child.kind == CursorKind.MEMBER_REF_EXPR:
                ref = child.referenced
                if ref and ref.spelling in ("setObjectName", "setAccessibleName"):
                    callee_name = ref.spelling
                    for gc in child.get_children():
                        if gc.kind == CursorKind.UNEXPOSED_EXPR:
                            target_var = gc.referenced.spelling if gc.referenced else ""
                        elif gc.kind == CursorKind.DECL_REF_EXPR:
                            target_var = gc.spelling or ""
            elif child.kind == CursorKind.STRING_LITERAL:
                name_value = child.spelling.strip('"')

        if callee_name and target_var:
            named_calls.setdefault(target_var, set()).add(callee_name)
            if target_var in widgets:
                if target_var not in name_calls:
                    name_calls[target_var] = set()
                name_calls[target_var].add((callee_name, name_value))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Instance-level scan: one file
# ---------------------------------------------------------------------------


def _gap_fully_named(
    g: WidgetInstance,
    global_named_calls: dict[str, set[str]],
    text_named_calls: dict[str, set[str]],
) -> bool:
    """Decide whether a gap instance is actually fully named (cross-file merge).

    A gap is only rescued when it is fully named across all files. For an
    interactive QWidget that means BOTH setObjectName AND setAccessibleName
    present (in this file or another); a partially-named interactive widget
    would otherwise be silently dropped from the gap list. Non-widget
    interactive (QAction, QShortcut, ...) and decorative types need only one.

    Shared by scan_source and coverage_stats._run_cpp_scan so baseline and
    quality-gate scans agree on the same merge semantics.
    """
    present: set[str] = set()
    if g.has_object_name:
        present.add("setObjectName")
    if g.has_accessible_name:
        present.add("setAccessibleName")
    present |= global_named_calls.get(g.variable, set())
    present |= text_named_calls.get(g.variable, set())
    needs_both = _is_interactive_type(g.type_name) and not _is_non_widget_interactive(g.type_name)
    if needs_both:
        return {"setObjectName", "setAccessibleName"} <= present
    return len(present) > 0


# ---------------------------------------------------------------------------
# Instance-level scan: one file
# ---------------------------------------------------------------------------


def _scan_one_file(
    file_path: str,
    rel_path: str,
    extra_args: list[str],
) -> tuple[str, list[WidgetInstance], list[WidgetInstance], dict[str, set[str]], str | None]:
    """Scan a single source file for widget instances.

    Returns (rel_path, ok_widgets, gap_widgets, named_calls, error_message).
    named_calls maps each variable name to the set of name-call types
    (setObjectName / setAccessibleName) present in this file, even if the
    variable is declared in another file (for cross-file merge).
    """
    try:
        index = Index.create()
        tu = index.parse(file_path, args=extra_args)
    except Exception as e:
        return rel_path, [], [], {}, str(e)

    widgets: dict[str, WidgetInstance] = {}
    ok_widgets_list: list[WidgetInstance] = []
    gap_widgets_list: list[WidgetInstance] = []
    name_calls: dict[str, set[tuple[str, str]]] = {}
    # Track ALL named variables + which call types, even those declared in other files
    named_calls: dict[str, set[str]] = {}
    class_name: str = ""

    # Locally-defined classes in this TU (real text-scanned bases). Prevents a
    # local class that shadows a same-named header interactive class from being
    # misreported as a gap (e.g. a decorative 'IconLabel : public QWidget'
    # defined in a .cpp shadowing iconutils.h's interactive IconLabel).
    header_path = _get_header_path(file_path)
    local_class_bases: dict[str, str] = _collect_local_class_bases(file_path, header_path)

    # Pass 1: find FIELD_DECLs for widget types
    # Only collect fields from the current file and its matching header.
    # Cross-file fields (e.g. commonpanel.h fields used in
    # remotemanagementpanel.cpp) are handled by the cross-file merge
    # in scan_source() using global_named_vars.
    for cursor in _iter_source_cursors(tu.cursor, file_path, header_path):
        try:
            if cursor.kind in (CursorKind.CLASS_DECL, CursorKind.STRUCT_DECL):
                if cursor.semantic_parent and cursor.semantic_parent.kind != CursorKind.TRANSLATION_UNIT:
                    continue
                if cursor.spelling and not cursor.spelling.startswith("__"):
                    class_name = cursor.spelling

            if cursor.kind == CursorKind.FIELD_DECL:
                type_name = cursor.type.spelling if cursor.type else ""
                var_name = cursor.spelling or ""
                if not var_name or not type_name:
                    continue
                is_ui = _is_ui_type(type_name)
                is_interactive = _is_interactive_type(type_name)
                is_layout = _is_layout_type(type_name)
                is_decorative = _is_decorative_type(type_name)

                if is_ui or is_interactive or (not is_layout and not is_decorative
                                                and _is_widget_pointer_type(type_name)):
                    if var_name not in widgets:
                        inst = WidgetInstance(
                            variable=var_name,
                            type_name=type_name,
                            source_file=rel_path,
                            class_name=class_name,
                            line=cursor.location.line,
                            role=_map_role(type_name),
                        )
                        widgets[var_name] = inst
        except Exception:
            continue

    # Pass 2: find setObjectName, setAccessibleName, set_Object_Name calls
    for cursor in _iter_source_cursors(tu.cursor, file_path):
        try:
            if cursor.kind == CursorKind.CALL_EXPR:
                spelling = cursor.spelling or ""
                children = list(cursor.get_children())
                target_var = ""
                name_value = ""
                call_type = ""

                if spelling in ("setObjectName", "setAccessibleName", "set_Object_Name"):
                    call_type = spelling
                    for child in children:
                        if child.kind == CursorKind.MEMBER_REF_EXPR:
                            ref = child.referenced
                            if ref and ref.spelling in ("setObjectName", "setAccessibleName"):
                                # referenced is the method, not the variable
                                # Extract target variable from child's own children
                                for gc in child.get_children():
                                    if gc.kind == CursorKind.UNEXPOSED_EXPR:
                                        target_var = gc.spelling or ""
                                        break
                            else:
                                target_var = ref.spelling if ref else ""
                        # STRING_LITERAL may be directly in CALL_EXPR children,
                        # or nested inside UNEXPOSED_EXPR (incomplete pointer resolve),
                        # or inside a constructor like QAnyStringView("CancelButton").
                        # Use recursive search for robustness across all nesting depths.
                        lit = _extract_string_literal(child)
                        if lit:
                            name_value = lit

                # Handle CALL_EXPR with empty spelling (dependent type, incomplete pointer)
                # e.g. m_cancelButton->setObjectName("CancelButton") when DPushButton is incomplete
                elif not spelling and children:
                    member_ref = None
                    string_lit = None
                    for child in children:
                        if child.kind == CursorKind.MEMBER_REF_EXPR:
                            member_ref = child
                        elif child.kind == CursorKind.STRING_LITERAL:
                            string_lit = child

                    if member_ref:
                        # STRING_LITERAL may be nested inside UNEXPOSED_EXPR
                        lit = _extract_string_literal(cursor)
                        if lit:
                            name_value = lit
                        # Extract target variable from MEMBER_REF_EXPR children
                        # May be nested: MEMBER_REF_EXPR -> UNEXPOSED_EXPR -> DECL_REF_EXPR
                        def _extract_target(c):
                            if c.kind == CursorKind.DECL_REF_EXPR:
                                return c.spelling or ""
                            if c.kind == CursorKind.UNEXPOSED_EXPR:
                                for gc in c.get_children():
                                    result = _extract_target(gc)
                                    if result:
                                        return result
                            return ""
                        for gc in member_ref.get_children():
                            if gc.kind == CursorKind.UNEXPOSED_EXPR:
                                target_var = _extract_target(gc)
                            elif gc.kind == CursorKind.DECL_REF_EXPR:
                                target_var = gc.spelling or ""
                            elif gc.kind == CursorKind.OVERLOADED_DECL_REF:
                                call_type = gc.spelling or ""
                        if not call_type:
                            # Try to get method name from OVERLOADED_DECL_REF at MEMBER_REF_EXPR level
                            for gc in member_ref.get_children():
                                if gc.kind == CursorKind.OVERLOADED_DECL_REF:
                                    call_type = gc.spelling or ""
                                    break
                        if target_var and not call_type:
                            call_type = "setObjectName"


                if target_var and call_type:
                    _ct = "setObjectName" if call_type == "set_Object_Name" else call_type
                    named_calls.setdefault(target_var, set()).add(_ct)
                    if target_var in widgets:
                        if target_var not in name_calls:
                            name_calls[target_var] = set()
                        name_calls[target_var].add((call_type, name_value))
                        # If we couldn't distinguish, also mark setAccessibleName
                        if call_type == "setObjectName" and not spelling:
                            name_calls[target_var].add(("setAccessibleName", name_value))

            # Handle UNEXPOSED_EXPR pattern (m_ptr->method() calls on pointer members)
            if cursor.kind == CursorKind.UNEXPOSED_EXPR:
                _detect_call_in_unexposed(cursor, widgets, name_calls, named_calls)

            # Find QAction creation with tr() text
            if cursor.kind == CursorKind.CXX_NEW_EXPR:
                created_type = cursor.type.spelling if cursor.type else ""
                if "QAction" in created_type or "DAction" in created_type:
                    tr_text = _extract_string_literal(cursor)
                    if tr_text:
                        parent = cursor.semantic_parent
                        if parent:
                            for sibling in parent.get_children():
                                if sibling.kind == CursorKind.BINARY_OPERATOR:
                                    lhs = list(sibling.get_children())
                                    if lhs and lhs[0].kind == CursorKind.DECL_REF_EXPR:
                                        var = lhs[0].spelling or ""
                                        if var in widgets:
                                            widgets[var].display_text = tr_text
                                            widgets[var].line = cursor.location.line
        except Exception:
            continue

    # Pass 3: classify
    for var_name, inst in widgets.items():
        if var_name in name_calls:
            for call_type, name_val in name_calls[var_name]:
                if call_type == "setObjectName":
                    inst.has_object_name = True
                    inst.existing_object_name = name_val
                elif call_type == "setAccessibleName":
                    inst.has_accessible_name = True
                    inst.existing_accessible_name = name_val
        # Resolve through locally-defined class bases first, so a local class
        # that shadows a same-named header interactive type is classified by
        # its real (local) base.
        eff_type = _resolve_local_base(inst.type_name, local_class_bases)
        if inst.type_name.endswith("*"):
            eff_type += " *"

        is_ui = _is_ui_type(eff_type)
        is_interactive = _is_interactive_type(eff_type)
        is_decorative = _is_decorative_type(eff_type)
        is_layout = _is_layout_type(eff_type)

        if is_layout:
            continue
        if is_decorative and not inst.has_object_name and not inst.has_accessible_name:
            continue

        if inst.has_object_name or inst.has_accessible_name:
            if is_interactive and not _is_non_widget_interactive(eff_type):
                # QWidget subclass: need BOTH setObjectName() AND setAccessibleName()
                if inst.has_object_name and inst.has_accessible_name:
                    ok_widgets_list.append(inst)
                else:
                    # Partial: only one of the two exists → still a gap
                    gap_widgets_list.append(inst)
            else:
                # Non-widget interactive (QAction, QShortcut) or decorative — either is sufficient
                ok_widgets_list.append(inst)
        elif is_interactive:
            if _is_non_widget_interactive(eff_type):
                # Non-widget (QAction, QShortcut): only setObjectName() is needed
                # Don't report if truly no name — scanner will still list it
                gap_widgets_list.append(inst)
            else:
                # QWidget subclass: needs both
                gap_widgets_list.append(inst)

    return rel_path, ok_widgets_list, gap_widgets_list, named_calls, None

# ---------------------------------------------------------------------------
# Worker with per-process clang init
# ---------------------------------------------------------------------------


def _worker_init(extra_args: list[str]):
    """Initialize per-worker clang state."""
    pass


def _worker_scan_batch(
    batch: list[tuple[str, str, list[str]]]
) -> list[tuple[str, list[WidgetInstance], list[WidgetInstance], set[str], str | None]]:
    return [_scan_one_file(*item) for item in batch]


# ---------------------------------------------------------------------------
# Main scan orchestrator
# ---------------------------------------------------------------------------


def scan_source(
    src_dir: str,
    build_dir: str | None = None,
    compile_commands: str | None = None,
    output_dir: str = ".",
    pool: multiprocessing.Pool | None = None,
    progress_cb: Any = None,
) -> ScanResult:
    """Scan a C++ source directory for widget instances missing AT-SPI names."""
    if not (_LIBCLANG_READY and _LIBCLANG_IMPORT_OK):
        logger.error("libclang not available. Install: sudo apt install python3-clang-18 libclang-18-dev")
        return ScanResult(source_dir=src_dir)

    root = Path(src_dir)
    if not root.is_dir():
        logger.error("Source directory not found: %s", src_dir)
        return ScanResult(source_dir=src_dir)

    # Extract project include paths from compile_commands (before resolve_custom_types)
    file_flags: dict[str, list[str]] | None = None
    if compile_commands:
        file_flags = _load_compile_commands(compile_commands)
    elif build_dir:
        file_flags = _load_compile_commands(str(Path(build_dir) / "compile_commands.json"))

    project_includes: list[str] = []
    if file_flags:
        # Collect -I flags that point into the project tree
        src_str = str(root)
        seen = set()
        for _file, flags in file_flags.items():
            for f in flags:
                if f.startswith("-I") and f not in seen:
                    seen.add(f)
                    inc_path = f[2:]
                    if inc_path and (inc_path.startswith(src_str) or src_str in inc_path):
                        project_includes.append(f)

    _TYPE_DB.resolve_custom_types(src_dir, project_includes)


    extra_args = ["-x", "c++", "-std=c++17", "-fPIC"]
    extra_args.extend(_get_cxx_stdlib_flags())
    extra_args.extend(_get_qt_dtk_include_flags())

    extensions = {".cpp", ".cxx", ".cc"}
    _SKIP_DIRS = {
        "tests", "test", "autotests", "autotest",
        "examples", "example", "samples", "sample", "demo", "demos",
        "build", "Build", "builddir", "_build",
        "cmake-build", "CMakeFiles", ".cmake",
        "debian", ".git", "3rdparty", "thirdparty", "third_party",
    }
    _SKIP_PREFIXES = ("test_", "moc_", "mocs_", "ui_", "qrc_")

    all_files: list[Path] = []
    for p in root.rglob("*"):
        if p.suffix not in extensions:
            continue
        if any(part in _SKIP_DIRS for part in p.parts):
            continue
        if p.stem.startswith(_SKIP_PREFIXES):
            continue
        all_files.append(p)
    all_files.sort()

    # Members actually instantiated via `new` in any .cpp file.
    # Used to filter: (a) dead-code members (declared but never new-ed),
    # and (b) external/parameter-assigned members (m_var = ctorParam or
    # m_var = externalPtr) — not created by this class, so naming is not
    # this class's responsibility.
    newed_members: set[str] = set()
    # Variables with setObjectName/setAccessibleName calls detected via text
    # regex — catches pointer-member calls (m_ptr->setObjectName(...)) that
    # libclang may miss when the pointer type is unresolved (UNEXPOSED_EXPR).
    # Maps variable -> set of call types present.
    text_named_calls: dict[str, set[str]] = {}

    _NEW_ASSIGN_RE = re.compile(r'(\w+)\s*=\s*new\s+')
    _NEW_INIT_RE = re.compile(r'(\w+)\s*\(\s*new\s+')
    _NAME_CALL_PATTERNS = [
        (re.compile(r'(\w+)\s*->\s*setObjectName\s*\('), "setObjectName"),
        (re.compile(r'(\w+)\s*->\s*setAccessibleName\s*\('), "setAccessibleName"),
        (re.compile(r'(\w+)\s*\.\s*setObjectName\s*\('), "setObjectName"),
        (re.compile(r'(\w+)\s*\.\s*setAccessibleName\s*\('), "setAccessibleName"),
    ]

    for f in all_files:
        try:
            content = Path(f).read_text(errors="replace")
            for m in _NEW_ASSIGN_RE.finditer(content):
                newed_members.add(m.group(1))
            for m in _NEW_INIT_RE.finditer(content):
                newed_members.add(m.group(1))
            for rx, call_type in _NAME_CALL_PATTERNS:
                for m in rx.finditer(content):
                    text_named_calls.setdefault(m.group(1), set()).add(call_type)
        except Exception:
            continue

    if not all_files:
        logger.warning("No C++ source files found in %s", src_dir)
        return ScanResult(source_dir=src_dir)


    # Extract include flags as complete pairs: '-isystem' takes its path as a
    # separate argv element, so a naive startswith filter would drop the paths
    # and leave dangling '-isystem' flags that break TU parsing.
    extra_includes: list[str] = []
    for i, f in enumerate(extra_args):
        if f == "-isystem" and i + 1 < len(extra_args):
            extra_includes.extend(["-isystem", extra_args[i + 1]])
        elif f.startswith("-I"):
            extra_includes.append(f)

    task_items: list[tuple[str, str, list[str]]] = []
    for p in all_files:
        abs_path = str(p.resolve())
        rel_path = str(p.relative_to(root))
        if file_flags and abs_path in file_flags:
            flags = list(file_flags[abs_path])
            # Merge extra include flags (DTK/Qt) into compile_commands flags
            # to ensure headers are found even if compile_commands is incomplete
            for inc in extra_includes:
                if inc not in flags:
                    flags.append(inc)
        else:
            flags = extra_args
        task_items.append((abs_path, rel_path, flags))

    total = len(task_items)
    n_workers = min(os.cpu_count() or 4, 8)
    batch_size = max(1, (total + n_workers - 1) // n_workers)
    batches = [task_items[i:i + batch_size] for i in range(0, total, batch_size)]

    all_ok: list[WidgetInstance] = []
    all_gaps: list[WidgetInstance] = []
    # Collect ALL named variables + call types across all files for cross-file merge
    global_named_calls: dict[str, set[str]] = {}
    parsed = 0
    failed = 0
    done = 0

    if pool is not None:
        for batch_results in pool.imap_unordered(_worker_scan_batch, batches):
            for rel_path, ok_list, gap_list, named_vars, error in batch_results:
                if error:
                    logger.warning("Failed to parse %s: %s", rel_path, error)
                    failed += 1
                else:
                    parsed += 1
                all_ok.extend(ok_list)
                all_gaps.extend(gap_list)
                for _v, _calls in named_vars.items():
                    global_named_calls.setdefault(_v, set()).update(_calls)
                done += 1
                if progress_cb:
                    progress_cb(done, total, rel_path)
    else:
        for batch in batches:
            for rel_path, ok_list, gap_list, named_vars, error in _worker_scan_batch(batch):
                if error:
                    logger.warning("Failed to parse %s: %s", rel_path, error)
                    failed += 1
                else:
                    parsed += 1
                all_ok.extend(ok_list)
                all_gaps.extend(gap_list)
                for _v, _calls in named_vars.items():
                    global_named_calls.setdefault(_v, set()).update(_calls)
                done += 1
                if progress_cb:
                    progress_cb(done, total, rel_path)

    # Cross-file merge: a gap may be named in another file
    # (e.g. commonpanel.h fields named in remotemanagementpanel.cpp).
    # A gap is only rescued if it is actually fully named — for interactive
    # QWidgets that means BOTH setObjectName AND setAccessibleName present
    # (in this file or another), otherwise a partially-named interactive
    # widget would be silently dropped from the gap list.
    still_gaps: list[WidgetInstance] = []
    for g in all_gaps:
        if _gap_fully_named(g, global_named_calls, text_named_calls):
            all_ok.append(g)
            continue
        # Dead-member / external-assignment filter: only report a gap if the
        # member is actually instantiated via `new` in some .cpp file.
        # - Dead code (declared but never new-ed) → not a real widget, skip.
        # - Parameter-assigned (m_var = ctorParam or externalPtr) → not this
        #   class's responsibility to name, skip.
        if g.variable not in newed_members:
            continue
        still_gaps.append(g)
    all_gaps = still_gaps

    # Sort for deterministic output order (stable dedup suffixes in naming.py)
    all_ok.sort(key=lambda w: (w.source_file, w.line, w.variable))
    all_gaps.sort(key=lambda w: (w.source_file, w.line, w.variable))

    result = ScanResult(
        source_dir=src_dir,
        total_files=total,
        parsed_files=parsed,
        failed_files=failed,
        widgets=all_ok + all_gaps,
        ok_widgets=all_ok,
        gap_widgets=all_gaps,
    )

    _write_outputs(result, output_dir)
    return result


# ---------------------------------------------------------------------------
# Output writing
# ---------------------------------------------------------------------------


def _widget_to_dict(w: WidgetInstance) -> dict[str, Any]:
    return {
        "variable": w.variable,
        "type": w.type_name,
        "source_file": w.source_file,
        "class_name": w.class_name,
        "line": w.line,
        "instantiation": w.instantiation,
        "has_object_name": w.has_object_name,
        "has_accessible_name": w.has_accessible_name,
        "existing_object_name": w.existing_object_name,
        "existing_accessible_name": w.existing_accessible_name,
        "display_text": w.display_text,
        "role": w.role,
        "context": w.context,
        "is_action": w.is_action,
        "action_owner": w.action_owner,
    }


def _write_outputs(result: ScanResult, output_dir: str) -> None:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    total = len(result.widgets)
    ok_count = len(result.ok_widgets)
    gap_count = len(result.gap_widgets)
    coverage = f"{ok_count / total * 100:.1f}%" if total else "0%"

    try:
        import yaml
    except ImportError:
        logger.error("PyYAML not installed. Run: pip install pyyaml")
        yaml = None

    ok_path = out / "pre_scan_ok.yaml"
    ok_data = {"version": "1.0", "widgets": [_widget_to_dict(w) for w in result.ok_widgets]}
    if yaml:
        with open(ok_path, "w", encoding="utf-8") as f:
            yaml.dump(ok_data, f, default_flow_style=False, allow_unicode=True, sort_keys=False)
    else:
        with open(ok_path, "w", encoding="utf-8") as f:
            json.dump(ok_data, f, indent=2, ensure_ascii=False)
    logger.info("Written %s (%d widgets)", ok_path, ok_count)

    gaps_path = out / "pre_scan_gaps.yaml"
    gaps_data = {
        "version": "1.0",
        "summary": {
            "total_widgets": total,
            "with_names": ok_count,
            "missing_names": gap_count,
            "coverage": coverage,
        },
        "gaps": [_widget_to_dict(w) for w in result.gap_widgets],
    }
    if yaml:
        with open(gaps_path, "w", encoding="utf-8") as f:
            yaml.dump(gaps_data, f, default_flow_style=False, allow_unicode=True, sort_keys=False)
    else:
        with open(gaps_path, "w", encoding="utf-8") as f:
            json.dump(gaps_data, f, indent=2, ensure_ascii=False)
    logger.info("Written %s (%d gaps)", gaps_path, gap_count)

    report_path = out / "pre_report.json"
    report = {
        "version": "1.0",
        "source_dir": result.source_dir,
        "stats": {
            "total_files": result.total_files,
            "parsed_files": result.parsed_files,
            "failed_files": result.failed_files,
        },
        "summary": {
            "total_widgets": total,
            "with_names": ok_count,
            "missing_names": gap_count,
            "coverage": coverage,
        },
    }
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    logger.info("Written %s", report_path)

    print(f"  Scan summary: {total} widgets in {result.total_files} files "
          f"({result.parsed_files} parsed, {result.failed_files} failed)",
          file=sys.stderr)
    if total:
        print(f"  With names: {ok_count}  Missing names: {gap_count}  Coverage: {coverage}",
              file=sys.stderr)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def main():
    parser = argparse.ArgumentParser(
        description="Scan C++ source for widget instances missing AT-SPI names",
    )
    parser.add_argument("--src", required=True, help="Source directory")
    parser.add_argument("--build", help="Build directory (for compile_commands.json)")
    parser.add_argument("--compile-commands", help="Path to compile_commands.json")
    parser.add_argument("--output", "-o", default=".",
                        help="Output directory (default: current dir)")
    args = parser.parse_args()

    if not args.build and not args.compile_commands:
        build_dir = Path(args.src) / "build"
        if build_dir.is_dir():
            args.build = str(build_dir)
            logger.info("Auto-detected build dir: %s", args.build)
        else:
            logger.warning("No build directory specified. Parsing without "
                           "compile_commands.json may fail.")

    result = scan_source(
        src_dir=args.src,
        build_dir=args.build,
        compile_commands=args.compile_commands,
        output_dir=args.output,
    )

    failure_rate = result.failed_files / result.total_files * 100 if result.total_files else 0
    if failure_rate > 20:
        logger.error("Parsing failed for %.0f%% of files (%d/%d)",
                      failure_rate, result.failed_files, result.total_files)
        return 2
    if result.failed_files > 0:
        logger.warning("Parsing failed for %d/%d files (%.0f%%)",
                       result.failed_files, result.total_files, failure_rate)
    return 0 if result.parsed_files > 0 else 1


if __name__ == "__main__":
    sys.exit(main())