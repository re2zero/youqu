# SPDX-FileCopyrightText: 2026 UnionTech Software Technology Co., Ltd.
#
# SPDX-License-Identifier: GPL-2.0-only

from __future__ import annotations

from collections import defaultdict
from pathlib import Path

import yaml

from src.at.generator.mapping_rules import STEP_TYPE_MAP
from src.at.parser.models import (
    CaseSuite,
    CaseStep,
    CasesDoc,
    ElementHint,
    ElementMappingsDoc,
    MappingEntry,
    MappingSelector,
    SuiteActionStep,
    SuiteCase,
    SuiteConfig,
)

_SKIP_HINTS = {ElementHint.visual_check, ElementHint.physical_device, ElementHint.cross_device}

try:
    from src.at.executor.handlers import HANDLERS as _EXEC_HANDLERS

    _VALID_ACTIONS = frozenset(_EXEC_HANDLERS.keys())
except ImportError:
    _VALID_ACTIONS = frozenset(
        {
            "session_start",
            "session_stop",
            "keyboard_press",
            "keyboard_hot_key",
            "keyboard_type",
            "keyboard_type_text",
            "mouse_click",
            "mouse_right_click",
            "mouse_double_click",
            "mouse_scroll",
            "mouse_drag",
            "element_action",
            "element_set_value",
            "dtk_main_menu",
            "dtk_context_menu",
            "dbus_call",
            "dbus_get_property",
            "wait",
            "screenshot",
            "assert_element",
            "assert_not_exists",
            "assert_window",
            "assert_window_count",
            "assert_process_running",
            "assert_process_not_running",
            "assert_file_exists",
            "assert_file_not_exists",
            "assert_image_exists",
            "assert_image_not_exists",
            "assert_ocr_exists",
            "assert_ocr_not_exists",
            "assert_vlm_reference",
        }
    )


def _load_yaml(path: str) -> dict | list | None:
    with open(path, encoding="utf-8") as f:
        return yaml.safe_load(f)


def _extract_elements(mappings: ElementMappingsDoc) -> dict[str, dict]:
    elements: dict[str, dict] = {}
    for m in mappings.mappings:
        if m.status != "mapped" or not m.element_ref or not m.selector:
            continue
        sel = m.selector.model_dump(mode="json", exclude_none=True)
        elements[m.element_ref] = sel
    return elements


def _extract_elements_from_cases(cases_doc: CasesDoc) -> dict[str, dict]:
    elements: dict[str, dict] = {}
    for suite in cases_doc.cases:
        for step in suite.steps:
            if step.element_ref and step.selector:
                elements[step.element_ref] = step.selector
            elif step.selector and not step.element_ref:
                # v2: selector-only steps — register by name as synthetic ref
                sel = step.selector
                name = sel.get("name", "") if isinstance(sel, dict) else ""
                if name:
                    ref_key = name
                    if ref_key not in elements:
                        elements[ref_key] = sel
    return elements


def _extract_elements_from_at_tree(at_tree_path: str) -> dict[str, dict]:
    try:
        tree_data = _load_yaml(at_tree_path)
    except (FileNotFoundError, OSError):
        return {}
    if not tree_data or not isinstance(tree_data, dict):
        return {}

    elements: dict[str, dict] = {}

    def _walk(nodes: list[dict]) -> None:
        for node in nodes:
            if not isinstance(node, dict):
                continue
            nid = node.get("id", "")
            if not nid:
                children = node.get("children", [])
                if children:
                    _walk(children)
                continue
            # 收录条件：
            # 1. classification 已设置且为 interactive → 收录
            # 2. classification 未设置（原始 dump）→ 收录所有有 name/role 的节点
            # 3. classification 为 container → 跳过（非交互节点若被引用，由
            #    _extract_elements_from_cases 单独收录）
            classification = node.get("classification", "")
            if classification and classification != "interactive":
                children = node.get("children", [])
                if children:
                    _walk(children)
                continue
            name = node.get("name", "")
            role = node.get("role", "")
            if name or role:
                elements[nid] = {"name": name, "role": role}
            children = node.get("children", [])
            if children:
                _walk(children)

    tree_nodes = tree_data.get("tree", [])
    if isinstance(tree_nodes, list):
        _walk(tree_nodes)

    return elements


def _write_yaml(data: dict | list, path: str) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    try:
        import yaml as pyyaml

        with open(path, "w", encoding="utf-8") as f:
            pyyaml.dump(data, f, allow_unicode=True, default_flow_style=False, sort_keys=False)
    except ImportError:
        import json

        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)


def _normalize_key(key: str | None) -> str | None:
    if not key:
        return None
    return key.lower().strip()


def _step_to_action_fallback(step: CaseStep) -> SuiteActionStep:
    action_name = STEP_TYPE_MAP.get(step.step_type.value, "element_action")

    if step.element_hint in (ElementHint.dtk_main_menu, ElementHint.dtk_context_menu):
        from src.at.generator.action_rules import classify_menu_type

        menu_type = classify_menu_type(step.description)
        if step.items:
            if menu_type == "dtk_main_menu":
                return SuiteActionStep(action="dtk_main_menu", items=step.items)
            return SuiteActionStep(action="dtk_context_menu", items=step.items, ref=step.element_ref, selector=step.selector)

    if step.element_hint == ElementHint.titlebar:
        return SuiteActionStep(action="element_action", do="click")

    if step.element_hint == ElementHint.keyboard_shortcut:
        return SuiteActionStep(action="keyboard_press", key=step.description)

    if step.element_hint == ElementHint.scroll:
        return SuiteActionStep(action="mouse_scroll", value=-3)

    if step.element_hint == ElementHint.dbus_call:
        return SuiteActionStep(action="dbus_call", value=step.value)

    if step.element_hint == ElementHint.screenshot:
        return SuiteActionStep(action="screenshot")

    if step.element_hint == ElementHint.drag_drop:
        return SuiteActionStep(action="element_action", do="drag")

    if step.element_hint == ElementHint.hover:
        return SuiteActionStep(action="element_action", do="hover")

    if step.element_hint == ElementHint.input_text:
        return SuiteActionStep(action="keyboard_type", text=step.description)

    if step.element_hint == ElementHint.assert_window:
        name_pattern = step.selector.get("name_pattern") if step.selector else None
        return SuiteActionStep(
            action="assert_window",
            name_pattern=name_pattern,
            app=step.text,
        )

    if step.element_hint == ElementHint.assert_element:
        return SuiteActionStep(
            action="assert_element",
            ref=step.element_ref,
            selector=step.selector,
        )

    if step.element_hint == ElementHint.assert_window_count:
        return SuiteActionStep(action="assert_window_count", expected=1)

    if step.element_hint == ElementHint.assert_not_exists:
        return SuiteActionStep(
            action="assert_not_exists",
            ref=step.element_ref,
            selector=step.selector,
        )

    return SuiteActionStep(action=action_name, do="click")


def _step_to_action(step: CaseStep) -> SuiteActionStep | None:
    if step.action and step.action not in _VALID_ACTIONS:
        print(
            f"Warning: invalid action '{step.action}' in step '{step.description[:50]}', skipping"
        )
        return None

    if step.action and step.action in _VALID_ACTIONS:
        key = _normalize_key(step.key) if step.action == "keyboard_press" else step.key

        if step.action == "dtk_main_menu":
            return SuiteActionStep(
                action="dtk_main_menu",
                items=step.items or [],
            )

        if step.action == "dtk_context_menu":
            return SuiteActionStep(
                action="dtk_context_menu",
                items=step.items or [],
                ref=step.element_ref,
                selector=step.selector,
            )

        if step.action == "keyboard_press":
            return SuiteActionStep(action="keyboard_press", key=key)

        if step.action == "keyboard_hot_key":
            return SuiteActionStep(action="keyboard_hot_key", key=step.key)

        if step.action == "keyboard_type":
            return SuiteActionStep(action="keyboard_type", text=step.text)

        if step.action == "mouse_click":
            return SuiteActionStep(
                action="mouse_click",
                ref=step.element_ref,
                selector=step.selector,
            )

        if step.action == "mouse_drag":
            return SuiteActionStep(
                action="mouse_drag",
                ref=step.element_ref,
                selector=step.selector,
            )

        if step.action == "element_action":
            do = "click"
            if step.element_hint == ElementHint.drag_drop:
                do = "drag"
            elif step.element_hint == ElementHint.hover:
                do = "hover"
            note = step.description if step.element_hint == ElementHint.dialog else None
            return SuiteActionStep(
                action="element_action",
                ref=step.element_ref,
                selector=step.selector,
                do=do,
                note=note,
            )

        if step.action == "mouse_scroll":
            scroll_val = -3
            if step.text and step.text.lstrip("-").isdigit():
                scroll_val = int(step.text)
            return SuiteActionStep(action="mouse_scroll", value=scroll_val)

        if step.action == "dbus_call":
            return SuiteActionStep(action="dbus_call", value=step.value)

        if step.action == "screenshot":
            return SuiteActionStep(action="screenshot")

        if step.action == "wait":
            return SuiteActionStep(action="wait", wait=1.0)

        if step.action == "assert_element":
            return SuiteActionStep(
                action="assert_element",
                ref=step.element_ref,
                selector=step.selector,
            )

        if step.action == "assert_not_exists":
            return SuiteActionStep(
                action="assert_not_exists",
                ref=step.element_ref,
                selector=step.selector,
            )

        if step.action == "assert_window":
            name_pattern = step.selector.get("name_pattern") if step.selector else None
            return SuiteActionStep(
                action="assert_window",
                name_pattern=name_pattern,
            )

        if step.action == "assert_window_count":
            expected = int(step.text) if step.text and step.text.isdigit() else 1
            return SuiteActionStep(action="assert_window_count", expected=expected)

        if step.action == "session_start":
            return SuiteActionStep(action="session_start", command=step.command or "")

        if step.action == "session_stop":
            return SuiteActionStep(action="session_stop")

        if step.action == "keyboard_type_text":
            return SuiteActionStep(action="keyboard_type_text", text=step.text)

        if step.action == "mouse_right_click":
            return SuiteActionStep(
                action="mouse_right_click",
                ref=step.element_ref,
                selector=step.selector,
            )

        if step.action == "mouse_double_click":
            return SuiteActionStep(
                action="mouse_double_click",
                ref=step.element_ref,
                selector=step.selector,
            )

        if step.action == "element_set_value":
            return SuiteActionStep(
                action="element_set_value",
                ref=step.element_ref,
                selector=step.selector,
                text=step.text,
            )

        if step.action == "dbus_get_property":
            return SuiteActionStep(action="dbus_get_property", value=step.value)

        if step.action == "assert_process_running":
            return SuiteActionStep(action="assert_process_running", app=step.text)

        if step.action == "assert_process_not_running":
            return SuiteActionStep(action="assert_process_not_running", app=step.text)

        if step.action == "assert_file_exists":
            return SuiteActionStep(action="assert_file_exists", path=step.text)

        if step.action == "assert_file_not_exists":
            return SuiteActionStep(action="assert_file_not_exists", path=step.text)

        if step.action == "assert_image_exists":
            return SuiteActionStep(action="assert_image_exists", path=step.text)

        if step.action == "assert_image_not_exists":
            return SuiteActionStep(action="assert_image_not_exists", path=step.text)

        if step.action == "assert_ocr_exists":
            return SuiteActionStep(action="assert_ocr_exists", value=step.text)

        if step.action == "assert_ocr_not_exists":
            return SuiteActionStep(action="assert_ocr_not_exists", value=step.text)

    if step.element_hint == ElementHint.vlm_assert:
        return SuiteActionStep(
            action="assert_vlm_reference",
            path=step.value,
            text=step.text,
        )

    return _step_to_action_fallback(step)


def _build_suite_cases(suite: CaseSuite) -> list[SuiteCase]:
    suite_cases: list[SuiteCase] = []
    current: SuiteCase | None = None
    case_counter = 0

    for i, step in enumerate(suite.steps):
        if step.element_hint in _SKIP_HINTS:
            continue

        action_step = _step_to_action(step)
        if action_step is None:
            continue

        if action_step.action in ("session_start", "session_stop"):
            if action_step.action == "session_start":
                if current and (current.steps or current.assert_steps):
                    suite_cases.append(current)
                case_counter += 1
                current = SuiteCase(
                    id=f"{suite.id}_s{case_counter}",
                    name=suite.name[:60],
                    description=suite.description[:120] if suite.description else "",
                    steps=[],
                )
            continue

        if action_step.action and action_step.action.startswith("assert_"):
            if current:
                current.assert_steps.append(action_step)
            else:
                case_counter += 1
                current = SuiteCase(
                    id=f"{suite.id}_s{case_counter}",
                    name=suite.name[:60],
                    description=suite.description[:120] if suite.description else "",
                    steps=[],
                    assert_steps=[action_step],
                )
            continue

        if current is None:
            case_counter += 1
            current = SuiteCase(
                id=f"{suite.id}_s{case_counter}",
                name=suite.name[:60],
                description=suite.description[:120] if suite.description else "",
                steps=[action_step],
            )
        else:
            current.steps.append(action_step)

    if current and (current.steps or current.assert_steps):
        suite_cases.append(current)

    return suite_cases


def _resolve_app_name(app_name: str, at_tree_path: str) -> str:
    if app_name:
        return app_name
    if at_tree_path:
        tree_path = Path(at_tree_path)
        if tree_path.exists():
            try:
                tree_data = _load_yaml(at_tree_path)
                if tree_data and isinstance(tree_data, dict):
                    metadata = tree_data.get("metadata", {})
                    if isinstance(metadata, dict):
                        app = metadata.get("app", "")
                        if app:
                            return app
            except Exception:
                pass
    raise ValueError(
        "Cannot determine app name. Use --app <name> or --at-tree <path> with metadata.app"
    )


def _write_app_optimization(cases_doc: CasesDoc, output_dir: str) -> None:
    entries: list[dict] = []
    for suite in cases_doc.cases:
        for i, step in enumerate(suite.steps):
            if step.needs_accessible_name:
                entries.append(
                    {
                        "suite_id": suite.id,
                        "step_index": i,
                        "description": step.description,
                        "suggestion": step.accessible_name_suggestion or "",
                        "element_hint": step.element_hint.value if step.element_hint else "",
                    }
                )

    if not entries:
        return

    lines = [
        "# App Optimization Recommendations",
        "",
        "The following UI elements need `setAccessibleName()` for AT-SPI automation:",
        "",
        "| Suite | Step | Description | Suggested Name | Hint |",
        "|--------|------|-------------|----------------|------|",
    ]
    for e in entries:
        lines.append(
            "| {} | {} | {} | {} | {} |".format(
                e["suite_id"], e["step_index"], e["description"], e["suggestion"], e["element_hint"]
            )
        )
    lines.append("")

    out_path = Path(output_dir) / "app-optimization.md"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"Wrote {out_path} ({len(entries)} entries)")


def generate_yaml(
    cases_path: str,
    output_dir: str,
    mappings_path: str = "",
    app_name: str = "",
    at_tree_path: str = "",
    assert_gate: bool = True,
) -> None:
    cases_data = _load_yaml(cases_path)
    if not cases_data:
        print(f"Error: {cases_path} is empty or invalid")
        return

    cases_doc = CasesDoc.model_validate(cases_data)

    elements: dict[str, dict] = _extract_elements_from_cases(cases_doc)

    if at_tree_path:
        tree_elements = _extract_elements_from_at_tree(at_tree_path)
        for ref, sel in tree_elements.items():
            if ref not in elements:
                elements[ref] = sel

    if mappings_path:
        mappings_data = _load_yaml(mappings_path)
        if mappings_data:
            mappings_doc = ElementMappingsDoc.model_validate(mappings_data)
            elements.update(_extract_elements(mappings_doc))

    # 统计 active cases 数量
    active_cases_count = sum(1 for s in cases_doc.cases if s.status not in ("skipped", "unsupported", "non_gui"))
    
    if active_cases_count > 0:
        elements_path = str(Path(output_dir) / "elements.yaml")
        _write_yaml({"elements": elements}, elements_path)
        print(f"Wrote {elements_path} ({len(elements)} elements)")
    else:
        print("No active cases found, skipping elements.yaml generation")

    resolved_app = _resolve_app_name(app_name, at_tree_path)

    _write_app_optimization(cases_doc, output_dir)

    suites_by_module: dict[str, list[CaseSuite]] = defaultdict(list)
    for suite in cases_doc.cases:
        if suite.status == "skipped":
            continue
        safe_module = suite.module.replace("/", "_")
        suites_by_module[safe_module].append(suite)

    total_cases = 0
    total_no_assert = 0

    for module, module_suites in suites_by_module.items():
        module_dir = Path(output_dir) / module
        module_dir.mkdir(parents=True, exist_ok=True)

        all_suite_cases: list[SuiteCase] = []

        for suite in module_suites:
            suite_cases = _build_suite_cases(suite)
            all_suite_cases.extend(suite_cases)

        if not all_suite_cases:
            continue

        session_cmd = resolved_app
        for ms in module_suites:
            for step in ms.steps:
                if step.action == "session_start" and step.command:
                    # 参数化绝对路径：将绝对路径命令转换为使用 launch.sh 或占位符
                    cmd = step.command
                    # 如果 command 包含绝对路径且包含文件名/图片路径，尝试参数化
                    if cmd.startswith("/") and (" /" in cmd or cmd.endswith(".jpg") or cmd.endswith(".png") or cmd.endswith(".jpeg")):
                        # 提取应用名和可能的文件参数
                        parts = cmd.split()
                        if len(parts) >= 2 and parts[0].endswith(resolved_app.split("/")[-1]) or parts[0].endswith(resolved_app):
                            # 尝试将命令参数化为 launch.sh 格式
                            file_arg = parts[1] if len(parts) > 1 else ""
                            if file_arg and file_arg.startswith("/"):
                                session_cmd = f"tests/at/launch.sh {resolved_app} {file_arg}"
                            else:
                                session_cmd = f"tests/at/launch.sh {resolved_app}"
                        else:
                            session_cmd = cmd
                    else:
                        session_cmd = cmd
                    break
            if session_cmd != resolved_app and not session_cmd.startswith("tests/at/launch.sh"):
                break

        suite_config = SuiteConfig(
            name=f"{module}_suite",
            app=resolved_app,
            module=module,
            setup=[SuiteActionStep(action="session_start", command=session_cmd, wait=3.0)],
            suites=all_suite_cases,
            teardown=[SuiteActionStep(action="session_stop")],
        )

        suite_path = module_dir / f"{module}.suite.yaml"
        _write_yaml(suite_config.model_dump(mode="json", exclude_none=True), str(suite_path))
        print(f"Wrote {suite_path} ({len(all_suite_cases)} suite cases)")

        no_assert = [sc for sc in all_suite_cases if not sc.assert_steps]
        if no_assert:
            print(f"  ⚠ {len(no_assert)}/{len(all_suite_cases)} cases have no assertions")
            for sc in no_assert:
                print(f"    - {sc.id}: {sc.name}")
            total_no_assert += len(no_assert)
        total_cases += len(all_suite_cases)

    if total_no_assert > 0:
        print(f"\n⚠ Assertion Coverage: {total_no_assert}/{total_cases} cases have no assertions")
        if assert_gate:
            import sys

            print("  assert-gate enabled: treating as error")
            sys.exit(1)
    elif total_cases > 0:
        print(f"\n✓ Assertion Coverage: all {total_cases} cases have assertions")
